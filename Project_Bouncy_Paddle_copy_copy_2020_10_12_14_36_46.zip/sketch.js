var ball,img,paddle;
var ball_1,paddle_1;
function preload() {
  /* preload your images here of the ball and the paddle */
  paddle=loadImage("paddle.png");
  ball=loadImage("ball.png")

}
function setup() {
  createCanvas(400, 400);
    ball_1=createSprite(40,200,20,20);
  ball_1.addImage(ball);
  ball_1.velocityX=9;
    paddle_1=createSprite(350,200,20,100);
  paddle_1.addImage(paddle);
}

function draw() {
  background(205,153,0);
  
  edges=createEdgeSprites();
  ball_1.bounceOff(edges[0]);
  
  ball_1.bounceOff(edges[2]);
  ball_1.bounceOff(edges[3]);
  ball_1.bounceOff(paddle_1,explosion);
  paddle_1.collide(edges);
  
  
  if(keyDown(UP_ARROW))
  {
     paddle_1.y=paddle_1.y-20;
  }
  
  if(keyDown(DOWN_ARROW))
  {
    paddle_1.y=paddle_1.y+20;
  }
  drawSprites();
  
}

function explosion()
{
  ball_1.velocityY=random(-9,9);
}
